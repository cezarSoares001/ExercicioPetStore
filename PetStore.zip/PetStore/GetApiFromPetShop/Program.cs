﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetApiFromPetShop
{
    class Program
    {
        static void Main(string[] args)
        {
            var cliente = new PetStoreClient();
            var getValidByOrderId = cliente.GetByOrderId(2);
            Console.WriteLine(getValidByOrderId);
            getValidByOrderId = cliente.GetByOrderId(30);
            Console.WriteLine(getValidByOrderId);
            var getInvalidByOrderId = cliente.GetByOrderId(12);
            Console.WriteLine(getInvalidByOrderId);
            getInvalidByOrderId = cliente.GetByOrderId(25);
            Console.WriteLine(getInvalidByOrderId);
            var postPet = cliente.PostPet();
            Console.WriteLine(postPet);
            Console.Read();
            var postUser = cliente.PostUser();
            Console.WriteLine(postUser);
            Console.Read();

        }
    }
}

